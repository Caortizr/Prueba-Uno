let clientes = [];

function validarFormulario(nombre, run, edad) {
    let errores = [];

    if (nombre.length < 3) {
        errores.push("El nombre debe tener al menos 3 caracteres.");
    }

    if (!/^[0-9]+-[0-9kK]$/.test(run)) {
        errores.push("El RUN debe tener formato válido (Ej: 12345678-9).");
    }

    if (isNaN(edad) || edad < 0 || edad > 120) {
        errores.push("La edad debe estar entre 0 y 120 años.");
    }

    if (errores.length > 0) {
        alert(errores.join("\n"));
        return false;
    }

    return true;
}

function registrarCliente() {
    const nombre = document.getElementById('nombre').value.trim();
    const run = document.getElementById('run').value.trim();
    const edad = parseInt(document.getElementById('edad').value.trim());

    if (!validarFormulario(nombre, run, edad)) {
        return false;
    }

    clientes.push({ nombre, run, edad });
    alert("Cliente registrado exitosamente");

    document.getElementById('form').reset();
    mostrarClientes();
    return false;
}

function mostrarClientes() {
    const tabla = document.getElementById("tablaClientes");
    const cuerpo = document.getElementById("tabla-body");
    cuerpo.innerHTML = "";

    if (clientes.length === 0) {
        tabla.style.display = "none";
        alert("No hay clientes registrados.");
        return;
    }

    clientes.forEach((cliente, index) => {
        const fila = document.createElement("tr");
        fila.innerHTML = `
            <td>${cliente.nombre}</td>
            <td>${cliente.run}</td>
            <td>${cliente.edad}</td>
            <td class="table-actions"><button onclick="eliminarCliente(${index})">Eliminar</button></td>
        `;
        cuerpo.appendChild(fila);
    });

    tabla.style.display = "block";
}

function eliminarCliente(index) {
    if (confirm("¿Estás seguro de que deseas eliminar este cliente?")) {
        clientes.splice(index, 1);
        mostrarClientes();
    }
}

function vaciarClientes() {
    if (confirm("¿Deseas vaciar la lista de clientes? Esta acción no se puede deshacer.")) {
        clientes = [];
        document.getElementById("tablaClientes").style.display = "none";
    }
}
