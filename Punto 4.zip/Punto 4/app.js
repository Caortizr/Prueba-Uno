const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Conexión a BD MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '', 
    database: 'prueba_uno'
});

//Validación en caso de error de conexión
db.connect((err) => {
    if (err) throw err;
    console.log('Conectado a MySQL');
});

// Middleware para parsear el cuerpo de las solicitudes
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Mostrar página principal con lista de clientes
app.get('/', (req, res) => {
    const sql = 'SELECT * FROM clientes';
    db.query(sql, (err, resultados) => {
        if (err) throw err;
        res.render('index', { clientes: resultados });
    });
});

// Registrar nuevo cliente
app.post('/registrar', (req, res) => {
    const { nombre, run, edad } = req.body;
    const sql = 'INSERT INTO clientes (nombre, run, edad) VALUES (?, ?, ?)';
    db.query(sql, [nombre, run, edad], (err, result) => {
        if (err) throw err;
        res.redirect('/');
    });
});

// Eliminar cliente individualmente
app.post('/eliminar/:id', (req, res) => {
    const id = req.params.id;
    const sql = 'DELETE FROM clientes WHERE id = ?';
    db.query(sql, [id], (err) => {
        if (err) throw err;
        res.redirect('/');
    });
});

// Eliminar todos los clientes de la base de datos
app.post('/vaciar', (req, res) => {
    const sql = 'DELETE FROM clientes';
    db.query(sql, (err) => {
        if (err) throw err;
        res.redirect('/');
    });
});

//Inicio del servidor
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
