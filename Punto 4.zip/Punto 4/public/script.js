function validarFormulario() {
    const nombre = document.getElementById('nombre').value.trim();
    const run = document.getElementById('run').value.trim();
    const edad = parseInt(document.getElementById('edad').value);

    let errores = [];

    // Valida largo de nombre, formato de RUN y rango de edad
    if (nombre.length < 3) {
        errores.push("El nombre debe tener al menos 3 caracteres.");
    }

    if (!/^[0-9]+-[0-9kK]$/.test(run)) {
        errores.push("El RUN debe tener formato válido (Ej: 12345678-9).");
    }

    if (isNaN(edad) || edad < 0 || edad > 120) {
        errores.push("La edad debe estar entre 0 y 120 años.");
    }

    if (errores.length > 0) {
        alert(errores.join("\n"));  // alerta con los errores 
        return false;
    }

    return true; // retorna true si todo está correcto
}