-- Creación Base de datos: prueba_uno

CREATE DATABASE IF NOT EXISTS `prueba_uno` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

-- Define la base de datos a usar
USE `prueba_uno`;

-- --------------------------------------------------------

-- Crea la tabla clientes

CREATE TABLE IF NOT EXISTS `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) DEFAULT NULL,
  `run` varchar(20) DEFAULT NULL,
  `edad` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
COMMIT;
